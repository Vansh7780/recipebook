const tl = gsap.timeline({ defaults: { ease: "power1.out" } });
tl.to(".text", { y: "0%", duration: 1, stagger: 0.25 });
tl.to(".slider", { y: "-100%", duration: 1.5, delay: 0.5 });
tl.to(".intro", { y: "-100%", duration: 1 }, "-=1");
tl.fromTo("nav", { opacity: 0 }, { opacity: 1, duration: 1 });
tl.fromTo(".big-text", { opacity: 0 }, { opacity: 1, duration: 1 }, "-=1");
tl.fromTo(".in-text", { opacity: 0 }, { opacity: 1, duration: 1 }, "-=1");
tl.fromTo("#image-track", { opacity: 0 }, { opacity: 1, duration: 1 }, "-=1");
/* const track = document.getElementsById("image-track");
window.onmousedown = e => {
    track.dataset.mouseDownAt = e.clientX;
}
window.onmouseup = () => {
    track.dataset.mouseDownAt = "0";
    track.data.prevPercentage = track.dataset.percentage = nextPercentage;
}
window.onmousemove = e => {
    if(track.dataset.mouseDownAt === "0") return;
    const mouseDelta = parseFloat(track.dataset.mouseDownAt) - e.clientX
          maxDelta = Window.innerwidth / 2;

          const percentage = (mouseDelta / maxDelta) * 0,
            nextPercentage = parseFloat(track.dataset.prevPercentage) + percentage;
            track.dataset.percentage = nextPercentage;
          track.style.transform = `translate(${percentage}%, -50%)`;
} */
function addContact() 
   { const name = document.getElementById('name').value;
    const phoneNumber = document.getElementById('phoneNumber').value;
    const listItem = document.createElement('li');
    listItem.innerHTML = `${name}: ${phoneNumber}`;
    document.getElementById('contactList').appendChild(listItem);
    document.getElementById('name').value = '';
    document.getElementById('phoneNumber').value = '';
}
document.getElementById('addContact').addEventListener('click', addContact);

/* const track = document.getElementById("image-track");

const handleOnDown = e => track.dataset.mouseDownAt = e.clientX;

const handleOnUp = () => {
  track.dataset.mouseDownAt = "0";  
  track.dataset.prevPercentage = track.dataset.percentage;
}

const handleOnMove = e => {
  if(track.dataset.mouseDownAt === "0") return;
  
  const mouseDelta = parseFloat(track.dataset.mouseDownAt) - e.clientX,
        maxDelta = window.innerWidth / 2;
  
  const percentage = (mouseDelta / maxDelta) * -100,
        nextPercentageUnconstrained = parseFloat(track.dataset.prevPercentage) + percentage,
        nextPercentage = Math.max(Math.min(nextPercentageUnconstrained, 0), -100);
  
  track.dataset.percentage = nextPercentage;
  
  track.animate({
    transform: `translate(${nextPercentage}%, -50%)`
  }, { duration: 1200, fill: "forwards" });
  
  for(const image of track.getElementsByClassName("image")) {
    image.animate({
      objectPosition: `${100 + nextPercentage}% center`
    }, { duration: 1200, fill: "forwards" });
  }
}

/* -- Had to add extra lines for touch events -- */

/* window.onmousedown = e => handleOnDown(e);

window.ontouchstart = e => handleOnDown(e.touches[0]);

window.onmouseup = e => handleOnUp(e);

window.ontouchend = e => handleOnUp(e.touches[0]);

window.onmousemove = e => handleOnMove(e);

window.ontouchmove = e => handleOnMove(e.touches[0]);*/