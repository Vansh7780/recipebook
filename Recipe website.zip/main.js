const getElement = (selector) => {
  const element = document.querySelector(selector)

  if (element) return element
  throw Error(
    `Please double check your class names, there is no ${selector} class`
  )
}

const links = getElement('.nav-links')
const navBtnDOM = getElement('.nav-btn')

navBtnDOM.addEventListener('click', () => {
  links.classList.toggle('show-links')
})

const date = getElement('#date')
const currentYear = new Date().getFullYear()
date.textContent = currentYear

const imageTrack = document.getElementById('image-track');
const scrollLeftBtn = document.getElementById('scrollLeftBtn');
const scrollRightBtn = document.getElementById('scrollRightBtn');

let scrollPosition = 0;
const imageWidth = 200;

scrollLeftBtn.addEventListener('click', () => {
  scrollPosition -= imageWidth;
  if (scrollPosition < 0) {
    scrollPosition = 0;
  }
  imageTrack.scrollTo({
    left: scrollPosition,
    behavior: 'smooth'
  });
});

scrollRightBtn.addEventListener('click', () => {
  const maxScroll = imageTrack.scrollWidth - imageTrack.clientWidth;
  scrollPosition += imageWidth;
  if (scrollPosition > maxScroll) {
    scrollPosition = maxScroll;
  }
  imageTrack.scrollTo({
    left: scrollPosition,
    behavior: 'smooth'
  });
});
